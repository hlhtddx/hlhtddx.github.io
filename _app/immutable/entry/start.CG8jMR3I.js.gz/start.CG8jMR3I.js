import{a as t}from"../chunks/entry.Bmb6taLf.js";export{t as start};
